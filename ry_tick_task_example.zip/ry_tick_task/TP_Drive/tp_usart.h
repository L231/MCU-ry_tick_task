

#ifndef __TP_USART_H__
	#define	__TP_USART_H__


#include "stm32f10x.h"
#include "tp_run.h"



#ifdef COMM_USART1
  #define  USARTx                         USART1
	#define  USARTx_CLK_CMD()               RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE)
	#define  USARTx_IRQn                    USART1_IRQn
	#define  USARTx_IRQHandler              USART1_IRQHandler
  #define  TX_GPIO                        GPIOA
  #define  RX_GPIO                        GPIOA
	#define  TX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE)
	#define  RX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE)
	#define  TX_PIN                         GPIO_Pin_9
	#define  RX_PIN                         GPIO_Pin_10
#elif defined(COMM_USART2)
  #define  USARTx                         USART2
	#define  USARTx_CLK_CMD()               RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE)
	#define  USARTx_IRQn                    USART2_IRQn
	#define  USARTx_IRQHandler              USART2_IRQHandler
  #define  TX_GPIO                        GPIOA
  #define  RX_GPIO                        GPIOA
	#define  TX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE)
	#define  RX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE)
	#define  TX_PIN                         GPIO_Pin_2
	#define  RX_PIN                         GPIO_Pin_3
#elif defined(COMM_USART3)
  #define  USARTx                         USART3
	#define  USARTx_CLK_CMD()               RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE)
	#define  USARTx_IRQn                    USART3_IRQn
	#define  USARTx_IRQHandler              USART3_IRQHandler
  #define  TX_GPIO                        GPIOB
  #define  RX_GPIO                        GPIOB
	#define  TX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE)
	#define  RX_GPIO_CLK_CMD()              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE)
	#define  TX_PIN                         GPIO_Pin_10
	#define  RX_PIN                         GPIO_Pin_11
#endif





#endif
