
#include "t_usb.h"
#include "tp_run.h"

#include "hw_config.h"
#include "usb_lib.h"



//static ry_task_t gTusb;


void _usb_task(void);


void t_usb_reg(void)
{
	usb_port_set(0);
	usb_port_set(1);
	
	Set_System();
	
	Set_USBClock();
	USB_Interrupts_Config();
 	USB_Init();
//	ry_task_reg(&gTusb, _usb_task, RY_TASK_MODE_SUPER, RY_TASK_READY, "Joystick_Keyboard", 0);
}




__IO uint8_t PrevXferComplete = 1;
//static char key = 'a';

void _usb_task(void)
{
//	if(Key_Scan(KEY1_GPIO_PORT, KEY1_GPIO_PIN) == KEY_ON)
//	{
//		Joystick_Send(key);
////			Delay_ms(35);
//		Joystick_Send(0);
////			Delay_ms(10);
//		key++;
//		if(key > 'z')
//			key = 'a';
//	}
}



uint8_t t_usb_task(Msg_t *msg)
{
    msg->len = 0;
    switch(msg->buf[1])
    {
        case 0 :
            tp_printf("#ERR_NO\r\n");
            break;
        case 1 :
            tp_printf("#ERR_POS_FAIL\r\n");
            break;
        case 2 :
            tp_printf("#ERR_POS_WARN\r\n");
            break;
    }
//	Joystick_Send(msg->buf[1]);
//	if(0 == msg->buf[1])
//		ry_task_standby(&gTusb);
//	else
//		ry_task_recover(&gTusb, RY_TASK_READY);
	return COMMAND_RUN_OK;
}

