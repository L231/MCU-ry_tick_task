#ifndef __T_USB_H__
#define	__T_USB_H__



#include "ry_comm_uart.h"

extern uint8_t t_usb_task(Msg_t *msg);




#endif
