/******************************************************************************
���ڣ�
�汾��V2.0
���ߣ�231
˵����ͨ�ſɲ��ô��ڡ�I2C�����������ַ�ʽ
���䣺
******************************************************************************/

#include "tp_run.h"
#include "ry_task.h"

#include "ry_cal.h"

/**
 * ����ͨ�Žӿڣ�
 *
 *            +--- PA9 ---+
 *     MCU ---+           +------ PC
 *            +--- PA10 --+
 *
 *
 **/
int main(void)
{
	float ovp, pack1, pack2;
	uint32_t cc1, cc1Base, cc1Pos, cc1Pos2;
	cc1     = ry_get_original(DAC_CalTable,      CH_SET_CC1_10A, 1000);
	cc1Base = ry_get_basic_original(DAC_CalTable,CH_SET_CC1_10A, 1000);
	cc1Pos  = ry_get_cal_point_pos(DAC_CalTable, CH_SET_CC1_10A, 500);
	cc1Pos2 = ry_get_cal_point_pos(DAC_CalTable, CH_SET_CC1_10A, 1000);
	ovp     = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_OVP, 450);
	pack1   = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_PACK, 1643);
	pack2   = ry_get_actual(ADC_CalTable, CH_VOLT_ADC_PACK, 5267);
	ry_task_init();
	
	tp_printf("cc1     = %d\r\n", cc1);
	tp_printf("cc1Base = %d\r\n", cc1Base);
	tp_printf("cc1Pos  = %d\r\n", cc1Pos);
	tp_printf("cc1Pos2 = %d\r\n", cc1Pos2);
	tp_printf("ovp     = %f\r\n", ovp);
	tp_printf("pack1   = %f\r\n", pack1);
	tp_printf("pack2   = %f\r\n", pack2);
	while(1)
	{
		ry_task_run();
	}
}


