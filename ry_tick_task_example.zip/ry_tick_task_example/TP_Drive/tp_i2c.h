#ifndef __TP_I2C_H__
	#define	__TP_I2C_H__

#include "stm32f10x.h"










extern void TP_I2C1_Init(void);






#endif
