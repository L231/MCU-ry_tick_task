#include "tp_run.h"
#include "tp_usart.h"



extern void t_usb_reg(void);


void ry_board_init(void)
{
	tp_systick_cfg();
	t_usb_reg();
	tp_uart_reg();
}












